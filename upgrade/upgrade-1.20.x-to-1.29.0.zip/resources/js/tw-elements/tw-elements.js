import { Select, initTE } from "tw-elements";

initTE({ Select }, false); // set second parameter to true if you want to use a debugger