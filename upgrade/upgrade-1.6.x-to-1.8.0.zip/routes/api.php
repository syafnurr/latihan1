<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('{locale}/v1')->group(function () {
    Route::prefix('member')->group(function () {
        Route::post('login', [App\Http\Controllers\Api\MemberAuthController::class, 'login']);

        Route::middleware('auth:member_api', 'member.auth.api')->group(function () {
            Route::get('followed-cards', [App\Http\Controllers\Api\MemberCardController::class, 'getFollowedCards']);
            Route::get('transacted-cards', [App\Http\Controllers\Api\MemberCardController::class, 'getTransactedCards']);
        });
    });
    Route::prefix('partner')->group(function () {
        Route::post('login', [App\Http\Controllers\Api\PartnerAuthController::class, 'login']);

        Route::middleware('auth:partner_api', 'partner.auth.api')->group(function () {
            Route::get('cards', [App\Http\Controllers\Api\PartnerCardController::class, 'getCards']);
            Route::get('cards/{card_id}', [App\Http\Controllers\Api\PartnerCardController::class, 'getCard']);
        });
    });
});
