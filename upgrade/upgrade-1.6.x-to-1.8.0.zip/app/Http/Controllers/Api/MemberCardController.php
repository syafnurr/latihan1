<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Card\CardService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class MemberCardController extends Controller
{
    /**
     * Retrieve all cards a specific member follows.
     *
     * @OA\Get(
     *     path="/{locale}/v1/member/followed-cards",
     *     operationId="getMemberFollowedCards",
     *     tags={"Member", "Card"},
     *     summary="Retrieve all cards that a member follows",
     *     description="This endpoint retrieves all the cards that the authenticated member follows. It requires a valid member authentication token.",
     *     security={
     *         {"member_auth_token": {}}
     *     },
     *     @OA\Parameter(
     *         name="locale",
     *         in="path",
     *         description="Specifies the locale (e.g., `en-us`)",
     *         required=true,
     *         @OA\Schema(
     *             type="string",
     *             default="en-us"
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operation successful. Returns an array of cards followed by the member.",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Card"))
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated - the provided member token is not valid or missing.",
     *         @OA\JsonContent(ref="#/components/schemas/UnauthenticatedResponse")
     *     )
     * )
     *
     * @param string $locale
     * @param Request $request
     * @param CardService $cardService
     * @return Response
     */
    public function getFollowedCards(string $locale, Request $request, CardService $cardService): Response
    {
        // Retrieve the member object associated with the authenticated member's token.
        $member = $request->user('member_api');

        // Check if the member object could be retrieved.
        if(!$member) {
            // If not, return an error message and a 401 Unauthenticated status code.
            return response()->json(['message' => 'No member found'], 401);
        }

        // Get the authenticated member's ID.
        $memberId = $member->id;

        // Use the CardService to find all active cards followed by the member.
        $followedCards = $cardService->findActiveCardsFollowedByMember($memberId, $hideColumnsForPublic = true);

        // Combine the followed cards and remove duplicates based on their IDs.
        // Sort them by descending order of the member balance and then by the issue date.
        $cards = $followedCards->sortByDesc(function ($card) {
                return [$card->getMemberBalance(null), $card->issue_date];
            });

        // Return the sorted list of unique cards as a JSON response.
        return response()->json($cards);
    }

    /**
     * Retrieve all cards a specific member has transacted with.
     *
     * @OA\Get(
     *     path="/{locale}/v1/member/transacted-cards",
     *     operationId="getMemberTransactedCards",
     *     tags={"Member", "Card"},
     *     summary="Retrieve all cards that a member has transacted with",
     *     description="This endpoint retrieves all cards that the authenticated member has had transactions with. It requires a valid member authentication token.",
     *     security={
     *         {"member_auth_token": {}}
     *     },
     *     @OA\Parameter(
     *         name="locale",
     *         in="path",
     *         description="Specifies the locale (e.g., `en-us`)",
     *         required=true,
     *         @OA\Schema(
     *           type="string",
     *           default="en-us"
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operation successful. Returns an array of cards with which the member has transacted.",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Card"))
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated - the provided member token is not valid or missing.",
     *         @OA\JsonContent(ref="#/components/schemas/UnauthenticatedResponse")
     *     )
     * )
     *
     * @param string $locale
     * @param Request $request
     * @param CardService $cardService
     * @return Response
     */
    public function getTransactedCards(string $locale, Request $request, CardService $cardService): Response
    {
        // Retrieve the member object associated with the authenticated member's token.
        $member = $request->user('member_api');

        // Check if the member object could be retrieved.
        if(!$member) {
            // If not, return an error message and a 401 Unauthenticated status code.
            return response()->json(['message' => 'No member found'], 401);
        }

        // Get the authenticated member's ID.
        $memberId = $member->id;

        // Use the CardService to find all active cards the member has transacted with.
        $cardsWithTransactions = $cardService->findActiveCardsWithMemberTransactions($memberId, $hideColumnsForPublic = true);

        // Sort the cards by descending order of the member balance and then by the issue date.
        $cards = $cardsWithTransactions->sortByDesc(function ($card) {
            return [$card->getMemberBalance(null), $card->issue_date];
        });

        // Return the sorted list of cards as a JSON response.
        return response()->json($cards);
    }

}
