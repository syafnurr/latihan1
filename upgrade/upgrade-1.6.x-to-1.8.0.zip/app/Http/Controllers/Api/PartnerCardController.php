<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Card\CardService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PartnerCardController extends Controller
{
    /**
     * Retrieve all cards associated with a specific partner.
     *
     * @OA\Get(
     *     path="/{locale}/v1/partner/cards",
     *     operationId="getPartnerCards",
     *     tags={"Partner", "Card"},
     *     summary="Get all cards for a partner",
     *     description="This endpoint allows a partner to retrieve all cards associated with them.",
     *     security={
     *         {"partner_auth_token": {}}
     *     },
     *     @OA\Parameter(
     *         name="locale",
     *         in="path",
     *         description="The locale (e.g. `en-us`)",
     *         required=true,
     *         @OA\Schema(
     *           type="string",
     *           default="en-us"
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Card"))
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated",
     *         @OA\JsonContent(ref="#/components/schemas/UnauthenticatedResponse")
     *     )
     * )
     *
     * @param Request $request
     * @param CardService $cardService
     * @return Response
     */
    public function getCards(string $locale, Request $request, CardService $cardService): Response
    {
        // Check the authenticated partner
        $partner = $request->user('partner_api');

        if(!$partner) {
            // No partner could be retrieved from the token
            return response()->json(['message' => 'No partner found'], 401);
        }

        $partnerId = $partner->id;

        // Call the card service to retrieve the cards
        $cards = $cardService->findCardsFromPartner($partnerId, $orderBy = 'created_at', $orderByDirection = 'desc', $where = 'is_active', $whereValue = true, $hideColumnsForPublic = true);

        return response()->json($cards);
    }

    /**
     * Retrieve one active card by id, owned by the authenticated partner.
     *
     * @OA\Get(
     *     path="/{locale}/v1/partner/cards/{cardId}",
     *     operationId="getCard",
     *     tags={"Partner", "Card"},
     *     summary="Get a single card by its ID",
     *     description="This endpoint allows a partner to retrieve a single active card by its ID.",
     *     security={
     *         {"partner_auth_token": {}}
     *     },
     *     @OA\Parameter(
     *         name="locale",
     *         in="path",
     *         description="The locale (e.g. `en-us`)",
     *         required=true,
     *         @OA\Schema(
     *             type="string",
     *             default="en-us"
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="cardId",
     *         in="path",
     *         description="The ID of the card to retrieve",
     *         required=true,
     *         @OA\Schema(
     *             type="integer"
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation",
     *         @OA\JsonContent(ref="#/components/schemas/Card")
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated",
     *         @OA\JsonContent(ref="#/components/schemas/UnauthenticatedResponse")
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Not found",
     *         @OA\JsonContent(ref="#/components/schemas/NotFoundResponse")
     *     )
     * )
     *
     * @param Request $request
     * @param CardService $cardService
     * @param int $cardId
     * @return Response
     */
    public function getCard(string $locale, int $cardId, Request $request, CardService $cardService): Response
    {
        // Check the authenticated partner
        $partner = $request->user('partner_api');

        if(!$partner) {
            // No partner could be retrieved from the token
            return response()->json(['message' => 'No partner found'], 401);
        }

        // Call the card service to retrieve the card
        $card = $cardService->findActiveCard($cardId, $authUserIsOwner = true, $guardUserIsOwner = 'partner_api', $hideColumnsForPublic = true);

        if(!$card) {
            // No card found
            return response()->json(['message' => 'No card found'], 404);
        }

        return response()->json($card);
    }
}
